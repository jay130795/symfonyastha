<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_91f23d26d1e9c4d15bd74abc1f548fe71498140eaf4fd2e477e058e8a9bd1df4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5fe442652664dc5eb41336c6b9a3d341244177351bdc5d1cc88561c515afa221 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5fe442652664dc5eb41336c6b9a3d341244177351bdc5d1cc88561c515afa221->enter($__internal_5fe442652664dc5eb41336c6b9a3d341244177351bdc5d1cc88561c515afa221_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_68eb97cf55e28a8b318f3c10a7cb9cf2d0e39ab1347c05f3872580eb330c6fba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_68eb97cf55e28a8b318f3c10a7cb9cf2d0e39ab1347c05f3872580eb330c6fba->enter($__internal_68eb97cf55e28a8b318f3c10a7cb9cf2d0e39ab1347c05f3872580eb330c6fba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5fe442652664dc5eb41336c6b9a3d341244177351bdc5d1cc88561c515afa221->leave($__internal_5fe442652664dc5eb41336c6b9a3d341244177351bdc5d1cc88561c515afa221_prof);

        
        $__internal_68eb97cf55e28a8b318f3c10a7cb9cf2d0e39ab1347c05f3872580eb330c6fba->leave($__internal_68eb97cf55e28a8b318f3c10a7cb9cf2d0e39ab1347c05f3872580eb330c6fba_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_a2e900cadce1c332ba3adbf68d75e0af17fc2fe4a1ac39b0aeb45d411ceac892 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a2e900cadce1c332ba3adbf68d75e0af17fc2fe4a1ac39b0aeb45d411ceac892->enter($__internal_a2e900cadce1c332ba3adbf68d75e0af17fc2fe4a1ac39b0aeb45d411ceac892_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_60c726f4b216f68d9fa7bea0c57f2969cc61d780150ae3803a03163c09a2f9b7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_60c726f4b216f68d9fa7bea0c57f2969cc61d780150ae3803a03163c09a2f9b7->enter($__internal_60c726f4b216f68d9fa7bea0c57f2969cc61d780150ae3803a03163c09a2f9b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_60c726f4b216f68d9fa7bea0c57f2969cc61d780150ae3803a03163c09a2f9b7->leave($__internal_60c726f4b216f68d9fa7bea0c57f2969cc61d780150ae3803a03163c09a2f9b7_prof);

        
        $__internal_a2e900cadce1c332ba3adbf68d75e0af17fc2fe4a1ac39b0aeb45d411ceac892->leave($__internal_a2e900cadce1c332ba3adbf68d75e0af17fc2fe4a1ac39b0aeb45d411ceac892_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_6551b2b71dd154a4aa2f4c41c10bf9c55015ab6364a04ff191469111578e72a9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6551b2b71dd154a4aa2f4c41c10bf9c55015ab6364a04ff191469111578e72a9->enter($__internal_6551b2b71dd154a4aa2f4c41c10bf9c55015ab6364a04ff191469111578e72a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_117c42494fc9019fdf05b0aab20bcc9fadf9d21627c8cd699250c66c062024c9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_117c42494fc9019fdf05b0aab20bcc9fadf9d21627c8cd699250c66c062024c9->enter($__internal_117c42494fc9019fdf05b0aab20bcc9fadf9d21627c8cd699250c66c062024c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_117c42494fc9019fdf05b0aab20bcc9fadf9d21627c8cd699250c66c062024c9->leave($__internal_117c42494fc9019fdf05b0aab20bcc9fadf9d21627c8cd699250c66c062024c9_prof);

        
        $__internal_6551b2b71dd154a4aa2f4c41c10bf9c55015ab6364a04ff191469111578e72a9->leave($__internal_6551b2b71dd154a4aa2f4c41c10bf9c55015ab6364a04ff191469111578e72a9_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_ce5dda4942d44b7d56617b7c1f9f1e790c386a80455cf809cd4b70a07173ec0e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ce5dda4942d44b7d56617b7c1f9f1e790c386a80455cf809cd4b70a07173ec0e->enter($__internal_ce5dda4942d44b7d56617b7c1f9f1e790c386a80455cf809cd4b70a07173ec0e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_327b96453fd99036db3b42ef44f8934d8003f375e161073a9e2a9a026a16ef6b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_327b96453fd99036db3b42ef44f8934d8003f375e161073a9e2a9a026a16ef6b->enter($__internal_327b96453fd99036db3b42ef44f8934d8003f375e161073a9e2a9a026a16ef6b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_327b96453fd99036db3b42ef44f8934d8003f375e161073a9e2a9a026a16ef6b->leave($__internal_327b96453fd99036db3b42ef44f8934d8003f375e161073a9e2a9a026a16ef6b_prof);

        
        $__internal_ce5dda4942d44b7d56617b7c1f9f1e790c386a80455cf809cd4b70a07173ec0e->leave($__internal_ce5dda4942d44b7d56617b7c1f9f1e790c386a80455cf809cd4b70a07173ec0e_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "C:\\xampp\\htdocs\\project\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\exception.html.twig");
    }
}
