<?php

/* sorusor/sorular.html.twig */
class __TwigTemplate_6799cb3c7ccf2fed3b17691ba1055bbe9a34338367cab3f988fed15b7e1a745e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "sorusor/sorular.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a9219408b5335236560ca7e9976e659de05c8882d1f40931f22cc27c35f8ef10 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a9219408b5335236560ca7e9976e659de05c8882d1f40931f22cc27c35f8ef10->enter($__internal_a9219408b5335236560ca7e9976e659de05c8882d1f40931f22cc27c35f8ef10_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "sorusor/sorular.html.twig"));

        $__internal_46e7384a5b863e836cec55c2d2b682ec7152d06021d542d200339ee2949f558f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_46e7384a5b863e836cec55c2d2b682ec7152d06021d542d200339ee2949f558f->enter($__internal_46e7384a5b863e836cec55c2d2b682ec7152d06021d542d200339ee2949f558f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "sorusor/sorular.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a9219408b5335236560ca7e9976e659de05c8882d1f40931f22cc27c35f8ef10->leave($__internal_a9219408b5335236560ca7e9976e659de05c8882d1f40931f22cc27c35f8ef10_prof);

        
        $__internal_46e7384a5b863e836cec55c2d2b682ec7152d06021d542d200339ee2949f558f->leave($__internal_46e7384a5b863e836cec55c2d2b682ec7152d06021d542d200339ee2949f558f_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_f8f20814f4b8ddb19d8609f798dd5f8ea84412ccc4a3255eb1468ea6e2a5ec20 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f8f20814f4b8ddb19d8609f798dd5f8ea84412ccc4a3255eb1468ea6e2a5ec20->enter($__internal_f8f20814f4b8ddb19d8609f798dd5f8ea84412ccc4a3255eb1468ea6e2a5ec20_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_b20a3c37274e9d42cf93fc33daac3029d7318fb105ad65828d746026689837b9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b20a3c37274e9d42cf93fc33daac3029d7318fb105ad65828d746026689837b9->enter($__internal_b20a3c37274e9d42cf93fc33daac3029d7318fb105ad65828d746026689837b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "<div class=\"bs-example\" data-example-id=\"hoverable-table\">
<h2 class=\"page-header\">Questions</h2>
\t<table id=\"example\"  class=\"table table-hover\"> 
\t\t<thead> 
\t\t\t<tr> 
\t\t\t\t<th>No.</th> 
\t\t\t\t<th>Name</th> 
\t\t\t\t<th>Question</th> 
\t\t\t\t<th>Date</th> 
\t\t\t\t<th>Answer</th> 
\t\t\t</tr> 
\t\t</thead> 
\t\t\t<tbody> 
\t\t\t";
        // line 16
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["todos"] ?? $this->getContext($context, "todos")));
        foreach ($context['_seq'] as $context["_key"] => $context["todo"]) {
            // line 17
            echo "\t\t\t\t<tr> 
\t\t\t\t\t<th scope=\"row\">";
            // line 18
            echo twig_escape_filter($this->env, $this->getAttribute($context["todo"], "id", array()), "html", null, true);
            echo "</th> 
\t\t\t\t\t\t<td>";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($context["todo"], "name", array()), "html", null, true);
            echo "</td> 
\t\t\t\t\t\t<td>";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute($context["todo"], "question", array()), "html", null, true);
            echo "</td> 
\t\t\t\t\t\t<td>";
            // line 21
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["todo"], "date", array()), "Y-m-d H:i:s"), "html", null, true);
            echo "</td> 
\t\t\t\t\t\t<td><a href=\"\" class=\"btn btn-success\">Answer</a></td> 
\t\t\t\t</tr> 
\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['todo'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 25
        echo "\t\t\t</tbody> 
\t\t</table> 
</div>
";
        
        $__internal_b20a3c37274e9d42cf93fc33daac3029d7318fb105ad65828d746026689837b9->leave($__internal_b20a3c37274e9d42cf93fc33daac3029d7318fb105ad65828d746026689837b9_prof);

        
        $__internal_f8f20814f4b8ddb19d8609f798dd5f8ea84412ccc4a3255eb1468ea6e2a5ec20->leave($__internal_f8f20814f4b8ddb19d8609f798dd5f8ea84412ccc4a3255eb1468ea6e2a5ec20_prof);

    }

    public function getTemplateName()
    {
        return "sorusor/sorular.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 25,  83 => 21,  79 => 20,  75 => 19,  71 => 18,  68 => 17,  64 => 16,  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}
<div class=\"bs-example\" data-example-id=\"hoverable-table\">
<h2 class=\"page-header\">Questions</h2>
\t<table id=\"example\"  class=\"table table-hover\"> 
\t\t<thead> 
\t\t\t<tr> 
\t\t\t\t<th>No.</th> 
\t\t\t\t<th>Name</th> 
\t\t\t\t<th>Question</th> 
\t\t\t\t<th>Date</th> 
\t\t\t\t<th>Answer</th> 
\t\t\t</tr> 
\t\t</thead> 
\t\t\t<tbody> 
\t\t\t{% for todo in todos %}
\t\t\t\t<tr> 
\t\t\t\t\t<th scope=\"row\">{{todo.id}}</th> 
\t\t\t\t\t\t<td>{{todo.name}}</td> 
\t\t\t\t\t\t<td>{{todo.question}}</td> 
\t\t\t\t\t\t<td>{{todo.date|date('Y-m-d H:i:s')}}</td> 
\t\t\t\t\t\t<td><a href=\"\" class=\"btn btn-success\">Answer</a></td> 
\t\t\t\t</tr> 
\t\t\t{% endfor %}
\t\t\t</tbody> 
\t\t</table> 
</div>
{% endblock %}
", "sorusor/sorular.html.twig", "C:\\xampp\\htdocs\\project\\app\\Resources\\views\\sorusor\\sorular.html.twig");
    }
}
