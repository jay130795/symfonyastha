<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_596134ad84a45d3a703ef1c943d6679f4d623e85895794760a3bbcf0e91e4958 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c0f6fb417b4f9b08585784adae27ff77f87779bdd2a2c5907d82fd6f345f7432 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c0f6fb417b4f9b08585784adae27ff77f87779bdd2a2c5907d82fd6f345f7432->enter($__internal_c0f6fb417b4f9b08585784adae27ff77f87779bdd2a2c5907d82fd6f345f7432_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_ea6417e63834ab222392e31f929cdec77e4081e59b700728792c0002128b20b0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ea6417e63834ab222392e31f929cdec77e4081e59b700728792c0002128b20b0->enter($__internal_ea6417e63834ab222392e31f929cdec77e4081e59b700728792c0002128b20b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c0f6fb417b4f9b08585784adae27ff77f87779bdd2a2c5907d82fd6f345f7432->leave($__internal_c0f6fb417b4f9b08585784adae27ff77f87779bdd2a2c5907d82fd6f345f7432_prof);

        
        $__internal_ea6417e63834ab222392e31f929cdec77e4081e59b700728792c0002128b20b0->leave($__internal_ea6417e63834ab222392e31f929cdec77e4081e59b700728792c0002128b20b0_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_e86ee6e0250f462e354cfa38a5a87297f02bedd8b40d1567364ded90426eb948 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e86ee6e0250f462e354cfa38a5a87297f02bedd8b40d1567364ded90426eb948->enter($__internal_e86ee6e0250f462e354cfa38a5a87297f02bedd8b40d1567364ded90426eb948_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_cf1d918e967550a8b77f5f1138eb414891d7d45fd86f15ec084ad699106e3907 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cf1d918e967550a8b77f5f1138eb414891d7d45fd86f15ec084ad699106e3907->enter($__internal_cf1d918e967550a8b77f5f1138eb414891d7d45fd86f15ec084ad699106e3907_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_cf1d918e967550a8b77f5f1138eb414891d7d45fd86f15ec084ad699106e3907->leave($__internal_cf1d918e967550a8b77f5f1138eb414891d7d45fd86f15ec084ad699106e3907_prof);

        
        $__internal_e86ee6e0250f462e354cfa38a5a87297f02bedd8b40d1567364ded90426eb948->leave($__internal_e86ee6e0250f462e354cfa38a5a87297f02bedd8b40d1567364ded90426eb948_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_d498b582f0fb403b58937d699436f2fad32a371fa0a1444a9c16b507285f8816 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d498b582f0fb403b58937d699436f2fad32a371fa0a1444a9c16b507285f8816->enter($__internal_d498b582f0fb403b58937d699436f2fad32a371fa0a1444a9c16b507285f8816_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_7314ae3e9d817c030169d15110f034752b83fff35dc79ec9c1ee74c134f54c2c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7314ae3e9d817c030169d15110f034752b83fff35dc79ec9c1ee74c134f54c2c->enter($__internal_7314ae3e9d817c030169d15110f034752b83fff35dc79ec9c1ee74c134f54c2c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_7314ae3e9d817c030169d15110f034752b83fff35dc79ec9c1ee74c134f54c2c->leave($__internal_7314ae3e9d817c030169d15110f034752b83fff35dc79ec9c1ee74c134f54c2c_prof);

        
        $__internal_d498b582f0fb403b58937d699436f2fad32a371fa0a1444a9c16b507285f8816->leave($__internal_d498b582f0fb403b58937d699436f2fad32a371fa0a1444a9c16b507285f8816_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_70eee33e52bb0434ab0f1484849b3a53f2c4b9e300419fb5c1294635e9481484 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_70eee33e52bb0434ab0f1484849b3a53f2c4b9e300419fb5c1294635e9481484->enter($__internal_70eee33e52bb0434ab0f1484849b3a53f2c4b9e300419fb5c1294635e9481484_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_d3f776703c4de359454ff1875a2af8673ca9a734fd6414a66cc83a55a8d25a27 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d3f776703c4de359454ff1875a2af8673ca9a734fd6414a66cc83a55a8d25a27->enter($__internal_d3f776703c4de359454ff1875a2af8673ca9a734fd6414a66cc83a55a8d25a27_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_d3f776703c4de359454ff1875a2af8673ca9a734fd6414a66cc83a55a8d25a27->leave($__internal_d3f776703c4de359454ff1875a2af8673ca9a734fd6414a66cc83a55a8d25a27_prof);

        
        $__internal_70eee33e52bb0434ab0f1484849b3a53f2c4b9e300419fb5c1294635e9481484->leave($__internal_70eee33e52bb0434ab0f1484849b3a53f2c4b9e300419fb5c1294635e9481484_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\xampp\\htdocs\\project\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
