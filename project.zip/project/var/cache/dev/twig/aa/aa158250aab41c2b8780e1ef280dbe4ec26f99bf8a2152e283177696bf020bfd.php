<?php

/* base.html.twig */
class __TwigTemplate_cf276ec5c8aeca8007e33ee25c4885ab60c5782e044b68c641db76c6879257f8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b447e79ff6f24f01a7945f2ab731498f75efd8b61d08deb4a4045c2c2ea03aa0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b447e79ff6f24f01a7945f2ab731498f75efd8b61d08deb4a4045c2c2ea03aa0->enter($__internal_b447e79ff6f24f01a7945f2ab731498f75efd8b61d08deb4a4045c2c2ea03aa0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_fdd75ab83acff3522ac78d0b443ddaad5f7129b0af0a0c91eef3e47378288483 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fdd75ab83acff3522ac78d0b443ddaad5f7129b0af0a0c91eef3e47378288483->enter($__internal_fdd75ab83acff3522ac78d0b443ddaad5f7129b0af0a0c91eef3e47378288483_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "
<!DOCTYPE html>
<html lang=\"en\">
  <head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">
    <link rel=\"icon\" href=\"../../favicon.ico\">

           <title>";
        // line 13
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

    <!-- Bootstrap core CSS -->
    <link href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\" rel=\"stylesheet\">
\t
<link rel=\"stylesheet\" type=\"text/css\" href=\"https://cdn.datatables.net/1.10.15/css/dataTables.bootstrap.min.css\"/>
 ";
        // line 19
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 20
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />

\t\t</head>

  <body>

    <nav class=\"navbar navbar-inverse\">
      <div class=\"container\">
        <div class=\"navbar-header\">
          <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#navbar\" aria-expanded=\"false\" aria-controls=\"navbar\">
            <span class=\"sr-only\">Toggle navigation</span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
          </button>
          <a class=\"navbar-brand\" href=\"/sorusor\">Sour Sor</a>
        </div>
        <div id=\"navbar\" class=\"collapse navbar-collapse\">
          <ul class=\"nav navbar-nav\">
            <li><a href=\"/sorusor\">Home</a></li>
            <li><a href=\"/sorusor/soru-sar\">Ask Question</a></li>
            <li><a href=\"/sorusor/sorular\">View Question</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

    <div class=\"container\">
<div class=\"col-md-12\">
 ";
        // line 49
        $this->displayBlock('body', $context, $blocks);
        // line 50
        echo "</div>
     

    </div><!-- /.container -->
  ";
        // line 54
        $this->displayBlock('javascripts', $context, $blocks);
        // line 67
        echo "
   
  </body>
</html>
";
        
        $__internal_b447e79ff6f24f01a7945f2ab731498f75efd8b61d08deb4a4045c2c2ea03aa0->leave($__internal_b447e79ff6f24f01a7945f2ab731498f75efd8b61d08deb4a4045c2c2ea03aa0_prof);

        
        $__internal_fdd75ab83acff3522ac78d0b443ddaad5f7129b0af0a0c91eef3e47378288483->leave($__internal_fdd75ab83acff3522ac78d0b443ddaad5f7129b0af0a0c91eef3e47378288483_prof);

    }

    // line 13
    public function block_title($context, array $blocks = array())
    {
        $__internal_08a5838908bdac0150766ae6e67abae87c9d95929609b26428eb380d82c947be = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_08a5838908bdac0150766ae6e67abae87c9d95929609b26428eb380d82c947be->enter($__internal_08a5838908bdac0150766ae6e67abae87c9d95929609b26428eb380d82c947be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_d379156740bdef6d679e7d5eb515e049e9d1d3b12f3bb468154e15719c42e4c7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d379156740bdef6d679e7d5eb515e049e9d1d3b12f3bb468154e15719c42e4c7->enter($__internal_d379156740bdef6d679e7d5eb515e049e9d1d3b12f3bb468154e15719c42e4c7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Soru Sor!";
        
        $__internal_d379156740bdef6d679e7d5eb515e049e9d1d3b12f3bb468154e15719c42e4c7->leave($__internal_d379156740bdef6d679e7d5eb515e049e9d1d3b12f3bb468154e15719c42e4c7_prof);

        
        $__internal_08a5838908bdac0150766ae6e67abae87c9d95929609b26428eb380d82c947be->leave($__internal_08a5838908bdac0150766ae6e67abae87c9d95929609b26428eb380d82c947be_prof);

    }

    // line 19
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_07b87e97d8b5d959325f86c673fd479d498dffcdb3fcc565174e9860a4dc5521 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_07b87e97d8b5d959325f86c673fd479d498dffcdb3fcc565174e9860a4dc5521->enter($__internal_07b87e97d8b5d959325f86c673fd479d498dffcdb3fcc565174e9860a4dc5521_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_86666dcc7b5a804bdfb092661f48b460d81985cad256601c96beb4c6ad23ab46 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_86666dcc7b5a804bdfb092661f48b460d81985cad256601c96beb4c6ad23ab46->enter($__internal_86666dcc7b5a804bdfb092661f48b460d81985cad256601c96beb4c6ad23ab46_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_86666dcc7b5a804bdfb092661f48b460d81985cad256601c96beb4c6ad23ab46->leave($__internal_86666dcc7b5a804bdfb092661f48b460d81985cad256601c96beb4c6ad23ab46_prof);

        
        $__internal_07b87e97d8b5d959325f86c673fd479d498dffcdb3fcc565174e9860a4dc5521->leave($__internal_07b87e97d8b5d959325f86c673fd479d498dffcdb3fcc565174e9860a4dc5521_prof);

    }

    // line 49
    public function block_body($context, array $blocks = array())
    {
        $__internal_c7be08c512c43f27fca259444b2333f8ca6759d2df2d16b5efa74d6ca8773cd6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c7be08c512c43f27fca259444b2333f8ca6759d2df2d16b5efa74d6ca8773cd6->enter($__internal_c7be08c512c43f27fca259444b2333f8ca6759d2df2d16b5efa74d6ca8773cd6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_d7445df29a9673962d3ba2e7b9509b1baa61c1b2842bc0a9a28fb0cf42e269f0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d7445df29a9673962d3ba2e7b9509b1baa61c1b2842bc0a9a28fb0cf42e269f0->enter($__internal_d7445df29a9673962d3ba2e7b9509b1baa61c1b2842bc0a9a28fb0cf42e269f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_d7445df29a9673962d3ba2e7b9509b1baa61c1b2842bc0a9a28fb0cf42e269f0->leave($__internal_d7445df29a9673962d3ba2e7b9509b1baa61c1b2842bc0a9a28fb0cf42e269f0_prof);

        
        $__internal_c7be08c512c43f27fca259444b2333f8ca6759d2df2d16b5efa74d6ca8773cd6->leave($__internal_c7be08c512c43f27fca259444b2333f8ca6759d2df2d16b5efa74d6ca8773cd6_prof);

    }

    // line 54
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_2519d6ce2f04394119d8a189d5fb9e530eb94fbc6d668f34e9f1176fad51ddab = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2519d6ce2f04394119d8a189d5fb9e530eb94fbc6d668f34e9f1176fad51ddab->enter($__internal_2519d6ce2f04394119d8a189d5fb9e530eb94fbc6d668f34e9f1176fad51ddab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_f2deb10d70342eaf6434733a1132af9cf802ece921957e8b012f0d9a2c016cdd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f2deb10d70342eaf6434733a1132af9cf802ece921957e8b012f0d9a2c016cdd->enter($__internal_f2deb10d70342eaf6434733a1132af9cf802ece921957e8b012f0d9a2c016cdd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 55
        echo "  <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>
<script src=\"https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js\"></script>

<script type=\"text/javascript\" src=\"https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js\"></script>
<script type=\"text/javascript\">
\t
\$(document).ready(function(){
    \$('#example').DataTable();
});

</script>
  ";
        
        $__internal_f2deb10d70342eaf6434733a1132af9cf802ece921957e8b012f0d9a2c016cdd->leave($__internal_f2deb10d70342eaf6434733a1132af9cf802ece921957e8b012f0d9a2c016cdd_prof);

        
        $__internal_2519d6ce2f04394119d8a189d5fb9e530eb94fbc6d668f34e9f1176fad51ddab->leave($__internal_2519d6ce2f04394119d8a189d5fb9e530eb94fbc6d668f34e9f1176fad51ddab_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  172 => 55,  163 => 54,  146 => 49,  129 => 19,  111 => 13,  97 => 67,  95 => 54,  89 => 50,  87 => 49,  54 => 20,  52 => 19,  43 => 13,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("
<!DOCTYPE html>
<html lang=\"en\">
  <head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">
    <link rel=\"icon\" href=\"../../favicon.ico\">

           <title>{% block title %}Soru Sor!{% endblock %}</title>

    <!-- Bootstrap core CSS -->
    <link href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\" rel=\"stylesheet\">
\t
<link rel=\"stylesheet\" type=\"text/css\" href=\"https://cdn.datatables.net/1.10.15/css/dataTables.bootstrap.min.css\"/>
 {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />

\t\t</head>

  <body>

    <nav class=\"navbar navbar-inverse\">
      <div class=\"container\">
        <div class=\"navbar-header\">
          <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#navbar\" aria-expanded=\"false\" aria-controls=\"navbar\">
            <span class=\"sr-only\">Toggle navigation</span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
          </button>
          <a class=\"navbar-brand\" href=\"/sorusor\">Sour Sor</a>
        </div>
        <div id=\"navbar\" class=\"collapse navbar-collapse\">
          <ul class=\"nav navbar-nav\">
            <li><a href=\"/sorusor\">Home</a></li>
            <li><a href=\"/sorusor/soru-sar\">Ask Question</a></li>
            <li><a href=\"/sorusor/sorular\">View Question</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

    <div class=\"container\">
<div class=\"col-md-12\">
 {% block body %}{% endblock %}
</div>
     

    </div><!-- /.container -->
  {% block javascripts %}
  <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>
<script src=\"https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js\"></script>

<script type=\"text/javascript\" src=\"https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js\"></script>
<script type=\"text/javascript\">
\t
\$(document).ready(function(){
    \$('#example').DataTable();
});

</script>
  {% endblock %}

   
  </body>
</html>
", "base.html.twig", "C:\\xampp\\htdocs\\project\\app\\Resources\\views\\base.html.twig");
    }
}
