<?php

/* sorusor/soru-sar.html.twig */
class __TwigTemplate_e632d40bf9faafd14c98b7ebcf1a7f8e6d7036ccf32f6011cf133fab57ec2b9f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "sorusor/soru-sar.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_416f2272156d03ffa05ae8ab176eec3cfcb2b0d09324286e62eda5d880caf6d7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_416f2272156d03ffa05ae8ab176eec3cfcb2b0d09324286e62eda5d880caf6d7->enter($__internal_416f2272156d03ffa05ae8ab176eec3cfcb2b0d09324286e62eda5d880caf6d7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "sorusor/soru-sar.html.twig"));

        $__internal_f3fcf247244b79865826e06b9ebc895f5e7a4fbd725ff9e3a42a35907f903bb3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f3fcf247244b79865826e06b9ebc895f5e7a4fbd725ff9e3a42a35907f903bb3->enter($__internal_f3fcf247244b79865826e06b9ebc895f5e7a4fbd725ff9e3a42a35907f903bb3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "sorusor/soru-sar.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_416f2272156d03ffa05ae8ab176eec3cfcb2b0d09324286e62eda5d880caf6d7->leave($__internal_416f2272156d03ffa05ae8ab176eec3cfcb2b0d09324286e62eda5d880caf6d7_prof);

        
        $__internal_f3fcf247244b79865826e06b9ebc895f5e7a4fbd725ff9e3a42a35907f903bb3->leave($__internal_f3fcf247244b79865826e06b9ebc895f5e7a4fbd725ff9e3a42a35907f903bb3_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_349302664ccd71e96411018cf55fad61ef85c83ab180ee965850367b12c78372 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_349302664ccd71e96411018cf55fad61ef85c83ab180ee965850367b12c78372->enter($__internal_349302664ccd71e96411018cf55fad61ef85c83ab180ee965850367b12c78372_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_b70699844c4c2879771088eb5511705449d5ab8b59614b5783115b2ffa3f5f1a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b70699844c4c2879771088eb5511705449d5ab8b59614b5783115b2ffa3f5f1a->enter($__internal_b70699844c4c2879771088eb5511705449d5ab8b59614b5783115b2ffa3f5f1a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "<h2 class=\"page-header\">Ask Question</h2>
\t";
        // line 4
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start');
        echo "
\t";
        // line 5
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        echo "
\t";
        // line 6
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "
";
        
        $__internal_b70699844c4c2879771088eb5511705449d5ab8b59614b5783115b2ffa3f5f1a->leave($__internal_b70699844c4c2879771088eb5511705449d5ab8b59614b5783115b2ffa3f5f1a_prof);

        
        $__internal_349302664ccd71e96411018cf55fad61ef85c83ab180ee965850367b12c78372->leave($__internal_349302664ccd71e96411018cf55fad61ef85c83ab180ee965850367b12c78372_prof);

    }

    public function getTemplateName()
    {
        return "sorusor/soru-sar.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 6,  56 => 5,  52 => 4,  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}
<h2 class=\"page-header\">Ask Question</h2>
\t{{form_start(form)}}
\t{{form_widget(form)}}
\t{{form_end(form)}}
{% endblock %}
", "sorusor/soru-sar.html.twig", "C:\\xampp\\htdocs\\project\\app\\Resources\\views\\sorusor\\soru-sar.html.twig");
    }
}
