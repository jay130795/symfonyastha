<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Tbl_sorusor;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Form\Extension\Core\Type\TextType; 
use Symfony\Component\Form\Extension\Core\Type\TextareaType; 
use Symfony\Component\Form\Extension\Core\Type\SubmitType; 

class sorusor extends Controller
{
    /**
     * @Route("/sorusor", name="sorular")
     */
    public function buttonAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('sorusor/index.html.twig');
    }
	 /**
     * @Route("/sorusor/soru-sar", name="askques")
     */
    public function questionAction(Request $request)
    {
		$todo = new Tbl_sorusor;
		$form = $this->createFormBuilder($todo)
		->add('name', Texttype::class, array('attr' => 	array('class' =>'form-control' , 'style' => 'margin-bottom:15px')))
		->add('question', TextareaType::class, array('attr' => 	array('class' =>'form-control' , 'style' => 'margin-bottom:15px')))
		->add('save', SubmitType::class, array('label' => 'Submit','attr' => 	array('class' =>'btn btn-primary' , 'style' => 'margin-bottom:15px')))
		
		->getForm();
		$form->handleRequest($request);
		if($form->isSubmitted() && $form->isValid()){
			//get Data
			$name = $form['name']->getData();
			$question = $form['question']->getData();
			$now = new\DateTime('now');
			
			$todo->setName($name);
			$todo->setQuestion($question);
			$todo->setDate($now);
			
			$em = $this->getDoctrine()->getManager();
			$em->persist($todo);
			$em->flush();
			$this->addFlash(
				'Notice',
				'Question Added'
			);
			return $this->redirectToRoute('ask_ques');
		}
        // replace this example code with whatever you need
        return $this->render('sorusor/soru-sar.html.twig', array('form' => $form->createView()));
    }
		 /**
     * @Route("/sorusor/sorular", name="ask_ques")
     */
    public function viewAction()
    {	
		$todos = $this->getDoctrine()
		->getRepository('AppBundle:Tbl_sorusor')
		->findAll();
        // replace this example code with whatever you need
        return $this->render('sorusor/sorular.html.twig',array(
		'todos' =>$todos
		));
    }
}
